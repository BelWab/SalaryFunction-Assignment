# BAN6420 Assignment: Salary Data Processing

## Overview
This project involves processing salary data using Python and R. It includes:
- Data import
- Function creation
- Dictionary processing
- Error handling
- CSV export and folder zipping in Python
- Unzipping and displaying the data in R

## Files
- salary_assignment.ipynb: Python code in a Jupyter Notebook.
- unzip_display.R: R script to unzip the folder and read CSV.
- Employee_Profile.zip: Zipped folder containing the employee CSV.
- README.txt: This instruction file.

## Instructions
1. Open and run the Jupyter Notebook to process and export employee data.
2. Run the R script to unzip and view the employee CSV file.
