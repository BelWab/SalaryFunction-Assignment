# unzip_display.R
unzip("Employee_Profile.zip")
data <- read.csv("Employee_Profile/gary_jimenez_profile.csv")
print(data)
